# @idem.angecy/fetch

Утилитарный пакет. Имитация запросов через ts файлы для dev режима.

## Поддерживаемые клиенты
- **Mock** — Клиент подмена запросов на ts файлы;
- **Request** — Клиент для fetch/XMLHttpRequest;

## Обязательные env пропсы для работы пакета
| Ключ          | Тип    | Значение                | Описание                   |
|---------------|--------|-------------------------|----------------------------|
| HTTP_CLIENT   | enum   | mock                    | Мок клиент                 |
|               |        | api                     | Fetch/XMLHttpRequest       |
| AUTH_TYPE     | enum   | bearer                  | Bearer авторизация         |
|               |        | basic                   | Базовая авторизация        |
| AUTH_TOKEN    | string | ********                | Токен bearer авторизации   |
| AUTH_LOGIN    | string | ********                | Имя пользователя           |
| AUTH_PASSWORD | string | ********                | Пароль                     |
| API           | string | https://idem.cloud.ru   | Корневой endpoint          |
| DEBUG         | true   | true / или не указывать | Включить поддержку отладки |


## Клиенты

### MockHttpClient
Подмена реальных запросов на запросы к ts файлам. 
Поддерживает 4 запроса: 
- GET
- POST
- PUT
- DELETE

#### Пример запросов и транслитация к поиску файлов

Запросы:
- **GET** /example  - /apiStatic/example/index.ts
- **POST** /example  - /apiStatic/example/index-post.ts
- **PUT** /example  - /apiStatic/example/index-put.ts
- **DELETE** /example  - /apiStatic/example/index-delete.ts

Альтернатиный поиск:

- **GET** /example  - /apiStatic/example.ts
- **POST** /example  - /apiStatic/example-post.ts
- **PUT** /example  - /apiStatic/example-put.ts
- **DELETE** /example  - /apiStatic/example-delete.ts

#### Поддерживаемые данные внутри файлов подмены

1. Export default {} - может возвращать объект. 
2. Export default (data: record<string, unknown>) => {} - может возвращать функцию с параметрами


#### Подключение к проекту с next.js

1. Задать .env параметры характеризующие текущий проект. 
2. В package.json в команды dev и build разместить следующий код
```json
{
  "scripts": {
    "dev": "idem_mock apiStatic watch | next dev",
    "build": "idem_mock apiStatic && next build"
  }
}
```
**apiStatic** - папка где находятся mock файлы

3. Создать файл api.ts и разместить следующий код 
```ts
import createHttpClient from '@idem.agency/fetch';

import mockAdapter from '../generated';
const api = createHttpClient({
  mockAdapter
});

export default api;
```
**Внимание :** 
файл generated.ts - всегда ложится в папку src (*Генерируется автоматически*). Путь указывать в соотвествии 
со сборкой проекта. и местом где вы ложите api.ts. Крайне рекомендуется использовать методологию fsd
